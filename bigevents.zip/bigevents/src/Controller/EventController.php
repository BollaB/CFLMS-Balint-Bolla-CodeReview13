<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\ HttpFoundation\Request;
use Symfony\ Bundle\FrameworkBundle\Controller\Controller ;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Event ;

class EventController extends AbstractController
{
   /**
    * @Route("/", name="home_page")
    */
   public function showAction()
   {
        $events = $this->getDoctrine()->getRepository('App:Event')->findAll();
        return $this->render('crud/index.html.twig',array('events'=>$events));
   }

    /**
    * @Route("/create", name="create_page")
    */
   public  function createAction(Request $request)
   {
       $event = new Event;

       $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('date_time', DateTimeType::class, array('attr'=> array('style'=>'margin-bottom:15px')))
              ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('image', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('contact_email', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('contact_phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('type', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theatre'=>'Theatre'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
              ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
              ->getForm();
          $form->handleRequest($request);

          if($form->isSubmitted() && $form->isValid()){
           
           $name = $form['name']->getData();
           $date_time = $form['date_time']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $contact_email = $form['contact_email']->getData();
           $contact_phone = $form['contact_phone']->getData();
           $address = $form['address']->getData();
           $url = $form['url']->getData();
           $type = $form['type']->getData();
           


           $event->setName($name);
           $event->setDateTime($date_time);
           $event->setDescription($description);
           $event->setImage($image);
           $event->setCapacity($capacity);
           $event->setContactEmail($contact_email);
           $event->setContactPhone($contact_phone);
           $event->setAddress($address);
           $event->setURL($url);
           $event->setType($type);
           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('home_page');
       }

       return $this->render('crud/create.html.twig', array('form' => $form->createView()));
       
   }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public  function editAction($id, Request $request)
   {
       $event = $this->getDoctrine()->getRepository('App:Event')->find($id);

           $event->setName($event->getName());
           $event->setDateTime($event->getDateTime());
           $event->setDescription($event->getDescription());
           $event->setImage($event->getImage());
           $event->setCapacity($event->getCapacity());
           $event->setContactEmail($event->getContactEmail());
           $event->setContactPhone($event->getContactPhone());
           $event->setAddress($event->getAddress());
           $event->setURL($event->getURL());
           $event->setType($event->getType());

        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('date_time', DateTimeType::class, array('attr'=> array('style'=>'margin-bottom:15px')))
              ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('image', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('contact_email', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('contact_phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
              ->add('url', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
              ->add('type', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theatre'=>'Theatre'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
              ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
              ->getForm();
          $form->handleRequest($request);

          if($form->isSubmitted()&& $form->isValid()){

             $name = $form['name']->getData();
             $date_time = $form['date_time']->getData();
             $description = $form['description']->getData();
             $image = $form['image']->getData();
             $capacity = $form['capacity']->getData();
             $contact_email = $form['contact_email']->getData();
             $contact_phone = $form['contact_phone']->getData();
             $address = $form['address']->getData();
             $url = $form['url']->getData();
             $type = $form['type']->getData();

             $em = $this->getDoctrine()->getManager();
             $event = $em->getRepository('App:Event')->find($id);
             $event->setName($name);
             $event->setDateTime($date_time);
             $event->setDescription($description);
             $event->setImage($image);
             $event->setCapacity($capacity);
             $event->setContactEmail($contact_email);
             $event->setContactPhone($contact_phone);
             $event->setAddress($address);
             $event->setURL($url);
             $event->setType($type);
             
             $em->flush();
             $this->addFlash(
                    'notice', 
                    'Event Updated'
                    );
             return $this->redirectToRoute('home_page');
          }

       return  $this->render('crud/edit.html.twig', array('event'=>$event, 'form'=>$form->createView()));
   }

    /**
    * @Route("/details/{id}", name="details_page")
    */
   public  function detailsAction($id)
   {
        $event = $this->getDoctrine()->getRepository('App:Event')->find($id);
        return $this->render('crud/details.html.twig', array('event'=>$event));
   }

   /**
    * @Route("/delete/{id}", name="event_delete")
    */
   public function deleteAction($id){
                $em = $this->getDoctrine()->getManager();
           $event = $em->getRepository('App:Event')->find($id);
           $em->remove($event);
            $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Removed'
                   );
            return $this->redirectToRoute('home_page');
   }
}
